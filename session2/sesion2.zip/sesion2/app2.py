"""
Dada la variable mensaje, escribir un programa que te diga cuantos numeros hay en el misma
mensaje = "Carlos,10,56,Maria,90,-1,Procesar,101,Logica"
Pistas: split..
"""

#programa principal
if __name__ == "__main__":
    pass
    
