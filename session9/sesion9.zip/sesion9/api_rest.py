import requests

response = requests.get('https://jsonplaceholder.typicode.com/users')
print(type(response.text))
data = response.json()

"""
Bajar los usuarios y guardarlos en un fichero en formato csv (id, username, email, website)
"""


#print(data)

