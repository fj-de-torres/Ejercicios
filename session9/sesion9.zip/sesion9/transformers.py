transformar_data = lambda lista : list(map(lambda item : tuple(item.split(',')) ,lista))


